using BEAMS_ERP.Components;
using BEAMS_ERP_DAL.Services;
using Blazored.LocalStorage;
using Blazorise;
using Blazorise.Bootstrap;
using Blazorise.Icons.FontAwesome;
using Microsoft.FluentUI.AspNetCore.Components;
using MudBlazor.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddSingleton<IGeneralService, GeneralService>();
builder.Services.AddScoped<IControlSettings, ControlSettingsServices>();
builder.Services.AddHttpClient<IControlSettings, ControlSettingsServices>(client =>
{
    client.BaseAddress = new Uri("http://localhost:5168/");
});
builder.Services.AddFluentUIComponents();
builder.Services.AddBlazoredLocalStorage();
builder.Services.AddBlazorise().AddBootstrapProviders().AddFontAwesomeIcons();
builder.Services.AddMudServices();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
