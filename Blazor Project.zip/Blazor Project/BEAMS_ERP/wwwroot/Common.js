﻿window.blazorFocusElement = (elementId) => {
    var element = document.getElementById(elementId);
    if (element) {
        element.focus();
    }
};
window.getNextElementByTabIndex = function (nextTabIndex) {
    var elements = document.querySelectorAll('[tabindex]');
    for (var i = 0; i < elements.length; i++) {
        if (parseInt(elements[i].getAttribute('tabindex')) === nextTabIndex) {
            return elements[i].id;
        }
    }
    return null;
};
ttt
//window.getCountryCode = function (phoneNumber) {
//    var parsedNumber = libphonenumber.parse(phoneNumber);
//    return parsedNumber.country.toString();
//}