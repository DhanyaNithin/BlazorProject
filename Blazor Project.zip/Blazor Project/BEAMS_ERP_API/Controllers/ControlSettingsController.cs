﻿using BEAMS_ERP_DAL.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;

namespace BEAMS_ERP_API.Controllers
{
    [Route("api/ControlSettings")]
    [ApiController]
    public class ControlSettingsController : ControllerBase
    {
        [HttpPost]
        [Route("GetControlSettings")]
        public IEnumerable<ControlSettings> GetControlSettings(clsControlSettings cs)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            ControlSettings controlSetting = new ControlSettings();
            return controlSetting.GetAllControlSetting(Connectionstring, cs);
        }

        [HttpPost]
        [Route("GetControlSettingsURL")]
        public IEnumerable<ControlSettingsURL> GetControlSettingsURL(ControlSettingsURL controlSettingurl)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return controlSettingurl.GetControlSettingURL(Connectionstring);
        }

        [HttpPost]
        [Route("LookupSearch")]
        public IEnumerable<clsLookupModel> LookupSearch(Lookup LKP)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return LKP.LookupSearch(Connectionstring);
        }

        [HttpPost]
        [Route("LookupValidate")]
        public string LookupValidate(Lookup LKP)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            DataTable dataTable = LKP.LookupValidate(Connectionstring);
            return JsonConvert.SerializeObject(dataTable);
        }

        [HttpPost]
        [Route("GetCodeByMode")]
        public string GetCodeByMode(clsLookupModel lkpmodal)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return lkpmodal.GetCodeByMode(Connectionstring);
        }

        [HttpPost]
        [Route("SaveData")]
        public string SaveData(clsInputModel ipmodal)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return ipmodal.SaveData(Connectionstring);
        }

        [HttpPost]
        [Route("GetPages")]
        public IEnumerable<clsPageSetup> GetPages(clsPageSetup cs)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return cs.GetPages(Connectionstring);
        }

        [HttpPost]
        [Route("GetPageDetails")]
        public clsPageSetup GetPageDetails(clsPageSetup pg)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return pg.GetPageDetails(Connectionstring);
        }

        [HttpPost]
        [Route("GetAllLanguages")]
        public IEnumerable<clsLanguage> GetAllLanguages(clsLanguage _lang)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return _lang.GetAllLanguages(Connectionstring);
        }
        [HttpPost]
        [Route("GetAllControlSettingsDet")]
        public IEnumerable<ControlSettings> GetAllControlSettingsDet(clsControlSettings csdet)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            ControlSettings controlSettingsDet = new ControlSettings();
            return controlSettingsDet.GetAllControlSettingDet(Connectionstring, csdet);
        }

        [HttpPost]
        [Route("GetAllTransactions")]
        public string GetAllTransactions(clsTransactions transactions)
        {
            string connectionstring = (string)HttpContext.Items["Connection"];
            return transactions.GetAllTransactions(connectionstring);
        }

        [HttpPost]
        [Route("GetNextDocNo")]
        public string GetNextDocNo(clsDocNo docno)
        {
            string connectionstring = (string)HttpContext.Items["Connection"];
            DataTable dataTable = docno.GetNextDocNo(connectionstring);
            return JsonConvert.SerializeObject(dataTable);
        }
    }
}
