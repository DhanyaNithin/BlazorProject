﻿using BEAMS_ERP_DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BEAMS_ERP_API.Controllers.Dashboard
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        [HttpPost]
        [Route("GetTotalSales")]
        public List<ChartData> GetTotalSales(ChartDataInput cd)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return cd.GetTotalSales(Connectionstring);
        }

        [HttpPost]
        [Route("GetTotalNoSales")]
        public List<ChartData> GetTotalNoSales(ChartDataInput cd)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return cd.GetTotalNoSales(Connectionstring);
        }
    }
}
