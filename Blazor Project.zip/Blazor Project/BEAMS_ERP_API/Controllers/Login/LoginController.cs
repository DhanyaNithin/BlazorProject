﻿using BEAMS_ERP_DAL.Models;
using Microsoft.AspNetCore.Mvc;

namespace BEAMS_ERP_API.Controllers
{
    [Route("api/login")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        [HttpPost]
        [Route("getLogin")]
        public string Login(clsLogin clsLogin)
        {
            string Connectionstring = (string)HttpContext.Items["Connection"];
            return clsLogin.Login(Connectionstring);
        }
    }
}
