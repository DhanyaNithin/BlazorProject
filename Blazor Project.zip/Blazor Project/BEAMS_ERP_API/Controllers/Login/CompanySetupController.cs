﻿using BEAMS_ERP_API.App_Start;
using BEAMS_ERP_DAL.Models;
using Microsoft.AspNetCore.Mvc;

namespace BEAMS_ERP_API.Controller
{
    [Route("api/companysetup")]
    [ApiController]
    public class CompanySetupController : ControllerBase
    {
        [HttpPost]
        [Route("GetCompanyDetails")]
        public IEnumerable<clsCompanySetup> GetAllCompany(clsCompanySetup _clsCompanySetup)
        {
            ConfigReader configReader = new ConfigReader();
            string Connectionstring = configReader.GetConnectionString();
            return _clsCompanySetup.GetAllCompany(Connectionstring);
        }

        [HttpPost]
        [Route("GetAllCompanyYearCode")]
        public IEnumerable<clsCompanySetup> GetAllCompanyYearCode(clsCompanySetup _clsCompanyyearcode)
        {
            ConfigReader configReader = new ConfigReader();
            string Connectionstring = configReader.GetConnectionString();
            return _clsCompanyyearcode.GetCompanyYearData(Connectionstring);

        }
    }
}
