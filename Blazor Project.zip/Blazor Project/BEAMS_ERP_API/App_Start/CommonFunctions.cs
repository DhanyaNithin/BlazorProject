﻿using System.Security.Cryptography;
using System.Text;


namespace BEAMS_ERP_API.App_Start
{
    public class CommonFunctions
    {

        public string BeamsMD5Decript(string Hash)
        {
            string result = "";
            var DES = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            var MD5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            DES.Key = MD5.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes("Beams"));
            DES.Mode = CipherMode.ECB;
            Byte[] Buffer = Convert.FromBase64String(Hash);
            result = System.Text.ASCIIEncoding.ASCII.GetString(DES.CreateDecryptor().TransformFinalBlock(Buffer, 0, Buffer.Length));
            return result;
        }

        public string BeamsMD5Encript(string text)
        {
            string result = "";
            var DES = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            var MD5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            DES.Key = MD5.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes("Beams"));
            DES.Mode = CipherMode.ECB;
            Byte[] Buffer = ASCIIEncoding.ASCII.GetBytes(text);
            result = Convert.ToBase64String(DES.CreateEncryptor().TransformFinalBlock(Buffer, 0, Buffer.Length));
            return result;
        }
    }
}
