﻿namespace BEAMS_ERP_API.App_Start
{
    public class ConfigReader
    {
        private readonly IConfiguration _configuration;

        public ConfigReader()
        {
            _configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .Build();
        }

        public string GetAppSettingValue(string key)
        {
            try
            {
                string value = _configuration[key];

                if (value != null)
                {
                    return value;
                }
                else
                {
                    Console.WriteLine($"Key '{key}' not found in appSettings.");
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading configuration: {ex.Message}");
                return null;
            }
        }

        public string GetConnectionString()
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                if (!string.IsNullOrEmpty(connectionString))
                {
                    return connectionString;
                }
                else
                {
                    Console.WriteLine("Connection string 'DefaultConnection' not found in appSettings.");
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading configuration: {ex.Message}");
                return null;
            }
        }
    }
}
