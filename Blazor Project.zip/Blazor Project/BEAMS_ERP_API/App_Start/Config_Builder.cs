﻿using System.Data;
using Microsoft.AspNetCore.Mvc.Filters;
using BEAMS_ERP_DAL.Models;

namespace BEAMS_ERP_API.App_Start
{
    public class Config_Builder
    {

        public class requestFilter : ActionFilterAttribute
        {
            

            public override void OnActionExecuting(ActionExecutingContext actionContext)
            {
                try
                {

                    //if (System.Configuration.ConfigurationManager.AppSettings["LOG_REQUEST"] == "1")
                    //{
                    //    using (Logging l = new Logging())
                    //    {
                    //        l.RequestBodyLog(actionContext);
                    //    }

                    //}

                    if (!actionContext.HttpContext.Items.ContainsKey("Connection") || actionContext.HttpContext.Items["Connection"] == null || actionContext.HttpContext.Items["Connection"].ToString() == "")
                    {

                        string TOKEN = (actionContext.HttpContext.Request.Headers.ContainsKey("TOKEN") ? actionContext.HttpContext.Request.Headers["TOKEN"] : "");
                        string COMPANY = actionContext.HttpContext.Request.Headers["COMPANY"];
                        string YEARCODE = actionContext.HttpContext.Request.Headers["YEARCODE"];
                        string APP_SERVER = "", APP_DB = "", APP_DBUSER = "", APP_DBPWD = "";
                        actionContext.HttpContext.Items["TOKEN"] = TOKEN;
                        actionContext.HttpContext.Items["COMPANY"] = COMPANY;
                        actionContext.HttpContext.Items["YEARCODE"] = YEARCODE;
                        //using (CommonFunctions CF = new CommonFunctions())
                        //{
                        //    actionContext.ActionArguments["IP"] = CF.GetIp();
                        //}
                        //SqlConnection connection = new SqlConnection();
                        ConfigReader configReader = new ConfigReader();
                        string BEAMS00Connectionstring = configReader.GetConnectionString();
                        //connection.ConnectionString = BEAMS00Connectionstring;

                        //connection.DbProviderName = "System.Data.SqlClient";
                        using (Beams0000 BEAMS = new Beams0000())
                        {
                            DataTable Dt = BEAMS.GetConnection(COMPANY, YEARCODE, BEAMS00Connectionstring);
                            if (Dt.Rows.Count > 0)
                            {
                                if (Dt.Rows[0]["DB1"] != null)
                                {
                                    //using (Logging el = new Logging())
                                    //{
                                    //    Exception ex = new Exception("UPDATE BEAMS_YEAR_DATA_JOB, DB DETAILS NOT FOUND");
                                    //    el.ErrorLoging(ex);

                                    //    actionContext.Response = actionContext.Request.CreateErrorResponse(System.Net.HttpStatusCode.BadRequest,
                                    //           "UPDATE BEAMS_YEAR_DATA_JOB DB DETAILS NOT FOUND", ex);
                                    //    BEAMS.create_Column();
                                    //}
                                //}
                                //else
                                //{
                                    CommonFunctions CF = new CommonFunctions();
                                    APP_DB = Dt.Rows[0]["BEAMS_DATABASE_NAME"].ToString();
                                    APP_SERVER = CF.BeamsMD5Decript(Dt.Rows[0]["DB1"].ToString());
                                    APP_DBUSER = CF.BeamsMD5Decript(Dt.Rows[0]["DB2"].ToString());
                                    APP_DBPWD = CF.BeamsMD5Decript(Dt.Rows[0]["DB3"].ToString());
                                    actionContext.HttpContext.Items["Connection"] = "Server=" + APP_SERVER + ";Database=" + APP_DB + ";User Id=" + APP_DBUSER + ";Password=" + APP_DBPWD + "; TrustServerCertificate=True;";
                                    //actionContext.ActionArguments["Connection"] = "Server=" + APP_SERVER + ";Database=" + APP_DB + ";User Id=" + APP_DBUSER + ";Password=" + APP_DBPWD + ";";
                                }

                            }
                            //else
                            //{
                            //    using (Logging el = new Logging())
                            //    {
                            //        Exception ex = new Exception("DB DETAILS NOT FOUND FOR CURRENT YEARCODE");
                            //        el.ErrorLoging(ex);

                            //        actionContext.Response = actionContext.Request.CreateErrorResponse(System.Net.HttpStatusCode.BadRequest,
                            //               "DB DETAILS NOT FOUND FOR CURRENT YEARCODE", ex);
                            //    }
                            //}
                        }

                    }
                }
                catch (Exception ex)
                {
                    //using (Logging el = new Logging())
                    //{

                    //    el.ErrorLoging(ex);

                    //    actionContext.Response = actionContext.Request.CreateErrorResponse(System.Net.HttpStatusCode.BadRequest,
                    //           "Company And Yearcode Required In Header Section", ex);
                    //}


                }
                try
                {
                    if (actionContext.HttpContext.Request.Headers.ContainsKey("requestId"))
                    {
                        string requestId = actionContext.HttpContext.Request.Headers["requestId"];
                    }
                    else
                    {
                        Random rnd = new Random();
                        actionContext.HttpContext.Request.Headers.Add("requestId", rnd.Next(1000).ToString());

                    }

                }
                catch
                {
                    Random rnd = new Random();
                    actionContext.HttpContext.Request.Headers.Add("requestId", rnd.Next(1000).ToString());
                }

                var modelState = actionContext.ModelState;
                if (!modelState.IsValid)
                {
                    string erros = "";
                    int index = 0;

                    foreach (var value in modelState.Values)
                    {
                        foreach (var errObj in value.Errors)
                        {
                            var clsobj = modelState.Keys.Where((x, i) => i == index);
                            string modelname = clsobj.FirstOrDefault().ToString().Split('[')[0].Split('.')[1];
                            if (modelname == "DataDetails")
                            {
                                string rowindex =
                                erros += errObj.ErrorMessage + "<br>" + errObj.Exception.Message + " At " + modelname + " Row " + (int.Parse(clsobj.FirstOrDefault().ToString().Split('[')[1].Split(']')[0]) + 1) + "<br>";
                            }
                            else
                            {
                                erros += errObj.ErrorMessage + "<br>" + (errObj.Exception != null ? errObj.Exception.Message : "") + " At " + modelname + "<br>";
                            }
                        }
                        index++;
                    }
                    erros = "0|" + erros;

                    //actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.OK, erros);
                }

            }


        }
    }
}
