﻿using BEAMS_ERP_DAL.Models;
using Blazored.LocalStorage;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;


namespace BEAMS_ERP_DAL.Services
{
    public class ControlSettingsServices : IControlSettings
    {
        private readonly HttpClient _httpClient;

        public ControlSettingsServices(HttpClient httpclient)
        {
            this._httpClient = httpclient;
        }

        public async Task SetDefaultRequestHeadersAsync(string Company, string Yearcode)
        {
            _httpClient.DefaultRequestHeaders.Add("COMPANY", Company);
            _httpClient.DefaultRequestHeaders.Add("YEARCODE", Yearcode);
        }

        public async Task<IEnumerable<ControlSettings>> GetAllAppControlSetting(clsControlSettings cs)
        {
            var json = JsonConvert.SerializeObject(cs);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/GetControlSettings", content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<ControlSettings>>();
        }

        public async Task<string> GetCodeByMode(clsLookupModel lkp)
        {
            var json = JsonConvert.SerializeObject(lkp);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/GetCodeByMode", content).Result;
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<IEnumerable<ControlSettingsURL>> GetControlSettingsURL(ControlSettingsURL cs)
        {

            var json = JsonConvert.SerializeObject(cs);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/GetControlSettingsURL", content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<ControlSettingsURL>>();
        }

        public async Task<string> SaveData(clsInputModel input)
        {
            var json = JsonConvert.SerializeObject(input);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/SaveData", content).Result;
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<string> ViewRecord(ControlSettingsURL cs)
        {
            var content = new StringContent(cs.PARAM, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync(cs.URL, content).Result;
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<IEnumerable<clsCompanySetup>> GetAllCompany(clsCompanySetup _clsCompanySetup)
        {
            var json = JsonConvert.SerializeObject(_clsCompanySetup);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/companysetup/GetCompanyDetails", content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<clsCompanySetup>>();
        }

        public async Task<IEnumerable<clsCompanySetup>> GetCompanyYearCode(clsCompanySetup _clsCompanySetup)
        {

            var json = JsonConvert.SerializeObject(_clsCompanySetup);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/companysetup/GetAllCompanyYearCode", content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<clsCompanySetup>>();
        }

        public async Task<string> Login(clsLogin _login)
        {
            var json = JsonConvert.SerializeObject(_login);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/Login/getLogin", content).Result;
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<IEnumerable<clsLookupModel>> GetLookupAll(Lookup lkp, String URL)
        {
            var json = JsonConvert.SerializeObject(lkp);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync(URL, content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<clsLookupModel>>();
        }

        public async Task<DataTable> GetLookupValidate(Lookup lkp, String URL)
        {
            var json = JsonConvert.SerializeObject(lkp);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync(URL, content).Result;
            string jsonresult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<DataTable>(jsonresult);
        }

        public async Task<IEnumerable<clsPageSetup>> GetPages(clsPageSetup cs)
        {
            var json = JsonConvert.SerializeObject(cs);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/GetPages", content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<clsPageSetup>>();
        }

        public async Task<clsPageSetup> GetPageDetails(clsPageSetup cs)
        {
            var json = JsonConvert.SerializeObject(cs);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/GetPageDetails", content).Result;
            return await response.Content.ReadFromJsonAsync<clsPageSetup>();
        }
        public async Task<IEnumerable<clsLanguage>> GetAllLanguages(clsLanguage lang)
        {
            var json = JsonConvert.SerializeObject(lang);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/GetAllLanguages", content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<clsLanguage>>();
        }
        public async Task<IEnumerable<ControlSettings>> GetAllControlSettingsDet(clsControlSettings controlSettingsDet)
        {
            var json = JsonConvert.SerializeObject(controlSettingsDet);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/ControlSettings/GetAllControlSettingsDet", content).Result;
            return await response.Content.ReadFromJsonAsync<IEnumerable<ControlSettings>>();
        }
        public async Task<DataTable> GetOtherData(ControlSettingsURL cs)
        {
            var content = new StringContent(cs.PARAM, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync(cs.URL, content).Result;
            string jsonresult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<DataTable>(jsonresult);
        }

        public async Task<List<ChartData>> GetTotalSales(ChartDataInput cd)
        {
            var json = JsonConvert.SerializeObject(cd);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/Dashboard/GetTotalSales", content).Result;
            return await response.Content.ReadFromJsonAsync<List<ChartData>>();
        }

        public async Task<List<ChartData>> GetTotalNoSales(ChartDataInput cd)
        {
            var json = JsonConvert.SerializeObject(cd);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("api/Dashboard/GetTotalNoSales", content).Result;
            return await response.Content.ReadFromJsonAsync<List<ChartData>>();
        }

    }
}
