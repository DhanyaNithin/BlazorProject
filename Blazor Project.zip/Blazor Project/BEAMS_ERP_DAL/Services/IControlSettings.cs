﻿using BEAMS_ERP_DAL.Models;
using System.Data;

namespace BEAMS_ERP_DAL.Services
{
    public interface IControlSettings
    {
        Task<IEnumerable<ControlSettings>> GetAllAppControlSetting(clsControlSettings cs);
        Task<IEnumerable<ControlSettingsURL>> GetControlSettingsURL(ControlSettingsURL cs);
        Task<string> ViewRecord(ControlSettingsURL cs);
        Task<string> GetCodeByMode(clsLookupModel lkp);
        Task<string> SaveData(clsInputModel input);
        Task<IEnumerable<clsCompanySetup>> GetAllCompany(clsCompanySetup _clsCompanySetup);
        Task<IEnumerable<clsCompanySetup>> GetCompanyYearCode(clsCompanySetup _clsCompanySetup);
        Task<string> Login(clsLogin login);
        Task SetDefaultRequestHeadersAsync(string Company, string Yearcode);
        Task<IEnumerable<clsLookupModel>> GetLookupAll(Lookup lkp, String URL);
        Task<DataTable> GetLookupValidate(Lookup lkp, String URL);
        Task<IEnumerable<clsPageSetup>> GetPages(clsPageSetup cs);
        Task<clsPageSetup> GetPageDetails(clsPageSetup cs);
        Task<IEnumerable<clsLanguage>> GetAllLanguages(clsLanguage lang);
        Task<IEnumerable<ControlSettings>> GetAllControlSettingsDet(clsControlSettings controlSettingsDet);
        Task<DataTable> GetOtherData(ControlSettingsURL cs);
        Task<List<ChartData>> GetTotalSales(ChartDataInput cd);
        Task<List<ChartData>> GetTotalNoSales(ChartDataInput cd);

    }
}
