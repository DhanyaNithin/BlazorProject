﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Services
{
    public class GeneralService : IGeneralService
    {
        public string CurrentLanguage { get; private set; } = "EN";
        public string CurrentDirection { get; private set; } = "ltr";
        public string CompanyCode { get; private set; } = "";
        public string YearCode { get; private set; } = "";
        public string UserName { get; private set; } = "";

        public void ChangeLanguage(string language, string direction)
        {
            if (CurrentLanguage != language)
            {
                CurrentLanguage = language;
            }
            if (CurrentDirection != direction)
            {
                CurrentDirection = direction;
            }
        }

        public void ChangeCompany(string company, string year)
        {
            if (CompanyCode != company)
            {
                CompanyCode = company;
            }
            if (YearCode != year)
            {
                YearCode = year;
            }
        }

        public void ChangeUser(string user)
        {
            if (UserName != user)
            {
                UserName = user;
            }
        }
    }
}
