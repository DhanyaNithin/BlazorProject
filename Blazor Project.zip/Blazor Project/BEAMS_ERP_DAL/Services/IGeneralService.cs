﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Services
{
    public interface IGeneralService
    {
        string CurrentLanguage { get; }
        string CurrentDirection { get; }
        string CompanyCode { get; }
        string YearCode { get; }
        string UserName { get; }
        void ChangeLanguage(string language, string direction);
        void ChangeCompany(string company, string year);
        void ChangeUser(string user);
    }
}
