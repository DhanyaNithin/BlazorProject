﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class clsGridDataModel
    {
        public int SRNO { get; set; }
        public string LOC { get; set; }
        public string STKCODE { get; set; }
        public string STKDESCP { get; set; }
        public string UNIT1 { get; set; }
        public string UNIT2 { get; set; }
        public decimal QTY1 { get; set; }
        public decimal QTY2 { get; set; }
        public decimal UNITCF { get; set; }
        public decimal RATEFC { get; set; }
        public decimal RATE { get; set; }
        public decimal RATEFC2 { get; set; }
        public decimal RATE2 { get; set; }
        public decimal GRAMTFC { get; set; }
        public decimal GRAMT { get; set; }
        public decimal AMTFC { get; set; }
        public decimal AMT { get; set; }
        public int DISCPERCENT { get; set; }
        public decimal DISC_AMTFC { get; set; }
        public decimal DISC_AMT { get; set; }
        public string REF1 { get; set; }
        public string REF2 { get; set; }
        public string REF3 { get; set; }
    }
}
