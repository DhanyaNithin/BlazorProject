﻿using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class clsDocNo
    {
        public string COMPANY { get; set; }
        public string DOCTYPE { get; set; }
        public DateTime? DOCDATE { get; set; }

        public DataTable GetNextDocNo(string connection)
        {
            using (SqlConnection conn = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("SELECT [dbo].[mfnNEXTDOCNO](@DOCTYPE,@COMPANY,@DATE) AS DOCNO", conn);
                cmd.Parameters.Add("@DOCTYPE", SqlDbType.VarChar).Value = DOCTYPE;
                cmd.Parameters.Add("@COMPANY", SqlDbType.VarChar).Value = COMPANY;
                cmd.Parameters.Add("@DATE", SqlDbType.VarChar).Value = DOCDATE;
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                using (var table = new DataTable())
                {
                    table.Load(dr);
                    dr.Close();
                    return table;
                }
            }
        }
    }
}
