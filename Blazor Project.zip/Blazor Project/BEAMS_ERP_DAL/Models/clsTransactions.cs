﻿using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class clsTransactions
    {
        public string? MODE { get; set; }
        public string TABLE_NAME { get; set; }
        public string COMPANY { get; set; }
        public string DOCNO { get; set; }
        public string DOCTYPE { get; set; }
        public string YEARCODE { get; set; }

        public string GetAllTransactions(string connections)
        {
            string jsonResult = string.Empty;
            List<clsTransactions> clsTransactions = new List<clsTransactions>();
            DataSet dtset = new DataSet();    
            using (SqlConnection conn = new SqlConnection(connections))
            {
                SqlCommand cmd = new SqlCommand("PR_GET_TRANSACTION", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("MODE", MODE);
                cmd.Parameters.AddWithValue("TABLE_NAME", TABLE_NAME);
                cmd.Parameters.AddWithValue("COMPANY", COMPANY);
                cmd.Parameters.AddWithValue("DOCNO", DOCNO);
                cmd.Parameters.AddWithValue("DOCTYPE", DOCTYPE);
                cmd.Parameters.AddWithValue("YEARCODE", YEARCODE);

                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dtset, "Transactions");

                jsonResult = JsonConvert.SerializeObject(dtset);
            }
            return jsonResult;
        }
    }

}
