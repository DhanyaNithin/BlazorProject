﻿using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System.Data;

namespace BEAMS_ERP_DAL.Models
{
    public class clsLookupModel
    {
        public string? CODE { get; set; }
        public string? DESCP { get; set; }
        public string? MODE { get; set; }
        public string? TABLE_NAME { get; set; }

        public string GetCodeByMode(string connectionstring)
        {
            string jsonResult = string.Empty;
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("PR_GET_CODEBYMODE", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("MODE", MODE);
                cmd.Parameters.AddWithValue("TABLE_NAME", TABLE_NAME);
                cmd.Parameters.AddWithValue("CODE", CODE);
                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Dictionary<string, object> row = new Dictionary<string, object>();

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            string columnName = reader.GetName(i);
                            object columnValue = reader.GetValue(i);
                            row[columnName] = columnValue;
                        }

                        jsonResult = JsonConvert.SerializeObject(row);
                    }
                }
                con.Close();
            }
            return jsonResult;
        }
    }
}
