﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace BEAMS_ERP_DAL.Models
{
    public class ControlSettings
    {
        //ConfigReader configReader = new ConfigReader();
        public string? COMPANY { get; set; }
        public string? CODE { get; set; }
        public int SRNO { get; set; }
        public int ORDER_NO { get; set; }
        public string? PARENT_CONTROL { get; set; } = "";
        public string? CTL_TYPE { get; set; } = "";
        public string? CTL_NAME { get; set; } = "";
        public string? CTL_TEXT { get; set; } = "";
        public string? FIELD_NAME { get; set; }
        public string? WIDTH { get; set; } = "";
        public string? DISPLAY_YN { get; set; } = "";
        public string? COMPULSARY_YN { get; set; } = "";
        public string? READONLY_YN { get; set; } = "";
        public string? DEPENDENT_CONTROL { get; set; } = "";
        public string? DEPENDENT_FIELD { get; set; } = "";
        public string? DISPLAY_REGION { get; set; } = "";
        public int DECIMAL_PRECISION { get; set; }
        public string? TABLE_TYPE { get; set; } = "";
        public string? LOOKUP_URL { get; set; } = "";
        public Lookup LOOKUP_PARAM { get; set; } = new Lookup();
        public string? LOOKUP_VALIDATE_URL { get; set; } = "";
        public Lookup LOOKUP_VALIDATE_PARAM { get; set; } = new Lookup();
        public int TAB_INDEX { get; set; }
        public string? AUTOFILL { get; set; } = "";
        public string? DEFAULT_VALUE { get; set; } = "";
        public string? LOOKUP_KEYS { get; set; } = "";
        public string? CALCULATION { get; set; } = "";
        public string COLUMN_NAME { get; set; } = "";
        public string COLUMN_CAPTION { get; set; } = "";
        public int COLUMN_ORDER { get; set; }
        public string MAIN_CONTROL { get; set; } = "";
        public IEnumerable<ControlSettings> GetAllControlSetting(string connectionstring, clsControlSettings cs)
        {
            List<ControlSettings> acsList = new List<ControlSettings>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("PR_GET_CONTROL_SETTING", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("COMPANY", cs.COMPANY);
                cmd.Parameters.AddWithValue("CODE", cs.CODE);
                cmd.Parameters.AddWithValue("LANGUAGE", cs.LANGUAGE);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ControlSettings iData = new ControlSettings();
                    iData.COMPANY = Convert.ToString(dr["COMPANY"]);
                    iData.CODE = Convert.ToString(dr["CODE"]);
                    iData.SRNO = Convert.ToInt32(dr["SRNO"]);
                    iData.ORDER_NO = Convert.ToInt32(dr["ORDER_NO"]);
                    iData.PARENT_CONTROL = Convert.ToString(dr["PARENT_CONTROL"]);
                    iData.CTL_TYPE = Convert.ToString(dr["CTL_TYPE"]);
                    iData.CTL_NAME = Convert.ToString(dr["CTL_NAME"]);
                    iData.CTL_TEXT = Convert.ToString(dr["CTL_TEXT"]);
                    iData.FIELD_NAME = Convert.ToString(dr["FIELD_NAME"]);
                    iData.WIDTH = Convert.ToString(dr["WIDTH"]);
                    iData.DISPLAY_YN = Convert.ToString(dr["DISPLAY_YN"]);
                    iData.COMPULSARY_YN = Convert.ToString(dr["COMPULSARY_YN"]);
                    iData.READONLY_YN = Convert.ToString(dr["READONLY_YN"]);
                    iData.DEPENDENT_CONTROL = Convert.ToString(dr["DEPENDENT_CONTROL"]);
                    iData.DEPENDENT_FIELD = Convert.ToString(dr["DEPENDENT_FIELD"]);
                    iData.DISPLAY_REGION = Convert.ToString(dr["DISPLAY_REGION"]);
                    if (dr["CTL_TYPE"].Equals("DECIMAL"))
                    {
                        if (string.IsNullOrEmpty(dr["DECIMAL_PRECISION"].ToString()))
                        {
                            iData.DECIMAL_PRECISION = 3;
                        }
                        else
                        {
                            iData.DECIMAL_PRECISION = Convert.ToInt32(dr["DECIMAL_PRECISION"]);
                        }
                    }

                    iData.TABLE_TYPE = Convert.ToString(dr["TABLE_TYPE"]);
                    iData.LOOKUP_URL = Convert.ToString(dr["LOOKUP_URL"]);
                    if (string.IsNullOrEmpty(dr["LOOKUP_PARAM"].ToString()))
                    {
                        iData.LOOKUP_PARAM = new Lookup();
                    }
                    else
                    {
                        iData.LOOKUP_PARAM = System.Text.Json.JsonSerializer.Deserialize<Lookup>(Convert.ToString(dr["LOOKUP_PARAM"]));
                    }
                    iData.LOOKUP_VALIDATE_URL = Convert.ToString(dr["LOOKUP_VALIDATE_URL"]);
                    if (string.IsNullOrEmpty(dr["LOOKUP_VALIDATE_PARAM"].ToString()))
                    {
                        iData.LOOKUP_VALIDATE_PARAM = new Lookup();
                    }
                    else
                    {
                        iData.LOOKUP_VALIDATE_PARAM = System.Text.Json.JsonSerializer.Deserialize<Lookup>(Convert.ToString(dr["LOOKUP_VALIDATE_PARAM"]));
                    }
                    iData.TAB_INDEX = Convert.ToInt32(dr["TAB_INDEX"]);
                    iData.AUTOFILL = Convert.ToString(dr["AUTOFILL"]);
                    iData.DEFAULT_VALUE = Convert.ToString(dr["DEFAULT_VALUE"]);
                    iData.LOOKUP_KEYS = Convert.ToString(dr["LOOKUP_KEYS"]);
                    iData.CALCULATION = Convert.ToString(dr["CALCULATION"]);
                    acsList.Add(iData);
                }
                con.Close();
            }
            return acsList;
        }

        public IEnumerable<ControlSettings> GetAllControlSettingDet(string connectionstring, clsControlSettings cs)
        {
            List<ControlSettings> acsList = new List<ControlSettings>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("PR_GET_CONTROL_SETTINGDET", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("COMPANY", cs.COMPANY);
                cmd.Parameters.AddWithValue("CODE", cs.CODE);
                cmd.Parameters.AddWithValue("LANGUAGE", cs.LANGUAGE);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ControlSettings iData = new ControlSettings();
                    iData.COMPANY = Convert.ToString(dr["COMPANY"]);
                    iData.CODE = Convert.ToString(dr["CODE"]);
                    iData.SRNO = Convert.ToInt32(dr["SRNO"]);
                    iData.ORDER_NO = Convert.ToInt32(dr["ORDER_NO"]);
                    iData.PARENT_CONTROL = Convert.ToString(dr["PARENT_CONTROL"]);
                    iData.CTL_TYPE = Convert.ToString(dr["CTL_TYPE"]);
                    iData.CTL_NAME = Convert.ToString(dr["CTL_NAME"]);
                    iData.CTL_TEXT = Convert.ToString(dr["CTL_TEXT"]);
                    iData.FIELD_NAME = Convert.ToString(dr["FIELD_NAME"]);
                    iData.WIDTH = Convert.ToString(dr["WIDTH"]);
                    iData.DISPLAY_YN = Convert.ToString(dr["DISPLAY_YN"]);
                    iData.COMPULSARY_YN = Convert.ToString(dr["COMPULSARY_YN"]);
                    iData.READONLY_YN = Convert.ToString(dr["READONLY_YN"]);
                    iData.DEPENDENT_CONTROL = Convert.ToString(dr["DEPENDENT_CONTROL"]);
                    iData.DEPENDENT_FIELD = Convert.ToString(dr["DEPENDENT_FIELD"]);
                    iData.DISPLAY_REGION = Convert.ToString(dr["DISPLAY_REGION"]);
                    if (dr["CTL_TYPE"].Equals("DECIMAL"))
                    {
                        if (string.IsNullOrEmpty(dr["DECIMAL_PRECISION"].ToString()))
                        {
                            iData.DECIMAL_PRECISION = 3;
                        }
                        else
                        {
                            iData.DECIMAL_PRECISION = Convert.ToInt32(dr["DECIMAL_PRECISION"]);
                        }
                    }

                    iData.TABLE_TYPE = Convert.ToString(dr["TABLE_TYPE"]);
                    iData.LOOKUP_URL = Convert.ToString(dr["LOOKUP_URL"]);
                    if (string.IsNullOrEmpty(dr["LOOKUP_PARAM"].ToString()))
                    {
                        iData.LOOKUP_PARAM = new Lookup();
                    }
                    else
                    {
                        iData.LOOKUP_PARAM = System.Text.Json.JsonSerializer.Deserialize<Lookup>(Convert.ToString(dr["LOOKUP_PARAM"]));
                    }
                    iData.LOOKUP_VALIDATE_URL = Convert.ToString(dr["LOOKUP_VALIDATE_URL"]);
                    if (string.IsNullOrEmpty(dr["LOOKUP_VALIDATE_PARAM"].ToString()))
                    {
                        iData.LOOKUP_VALIDATE_PARAM = new Lookup();
                    }
                    else
                    {
                        iData.LOOKUP_VALIDATE_PARAM = System.Text.Json.JsonSerializer.Deserialize<Lookup>(Convert.ToString(dr["LOOKUP_VALIDATE_PARAM"]));
                    }
                    iData.TAB_INDEX = Convert.ToInt32(dr["TAB_INDEX"]);
                    iData.AUTOFILL = Convert.ToString(dr["AUTOFILL"]);
                    iData.DEFAULT_VALUE = Convert.ToString(dr["DEFAULT_VALUE"]);
                    iData.LOOKUP_KEYS = Convert.ToString(dr["LOOKUP_KEYS"]);
                    iData.CALCULATION = Convert.ToString(dr["CALCULATION"]);
                    iData.COLUMN_NAME = Convert.ToString(dr["COLUMN_NAME"]);
                    iData.COLUMN_CAPTION = Convert.ToString(dr["COLUMN_CAPTION"]);
                    iData.COLUMN_ORDER = Convert.ToInt32(dr["COLUMN_ORDER"]);
                    iData.MAIN_CONTROL = Convert.ToString(dr["MAIN_CONTROL"]);

                    acsList.Add(iData);

                }
                con.Close();
            }
            return acsList;
        }
    }
}
