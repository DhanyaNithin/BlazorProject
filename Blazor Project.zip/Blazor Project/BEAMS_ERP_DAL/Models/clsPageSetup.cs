﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class clsPageSetup
    {
        public string CODE { get; set; } = "";
        public string PAGE_TITLE { get; set; } = "";
        public string TABLE_NAME { get; set; } = "";
        public string TYPE { get; set; } = "";

        public IEnumerable<clsPageSetup> GetPages(string connectionstring)
        {
            List<clsPageSetup> acsList = new List<clsPageSetup>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM PAGE_SETUP", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    clsPageSetup iData = new clsPageSetup();
                    iData.PAGE_TITLE = Convert.ToString(dr["PAGE_TITLE"]);
                    iData.CODE = Convert.ToString(dr["CODE"]);
                    iData.TABLE_NAME = Convert.ToString(dr["TABLE_NAME"]);
                    iData.TYPE = Convert.ToString(dr["TYPE"]);
                    acsList.Add(iData);
                }
                con.Close();
            }
            return acsList;
        }

        public clsPageSetup GetPageDetails(string connectionstring)
        {
            clsPageSetup iData = new clsPageSetup();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("PR_GET_PAGEDETAILS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("CODE", CODE);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    iData.PAGE_TITLE = Convert.ToString(dr["PAGE_TITLE"]);
                    iData.CODE = Convert.ToString(dr["CODE"]);
                    iData.TABLE_NAME = Convert.ToString(dr["TABLE_NAME"]);
                    iData.TYPE = Convert.ToString(dr["TYPE"]);
                }
                con.Close();
            }
            return iData;

        }
    }
}
