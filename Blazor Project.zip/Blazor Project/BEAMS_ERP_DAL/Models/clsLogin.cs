﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace BEAMS_ERP_DAL.Models
{
    public class clsLogin
    {

        public string USERNAME { get; set; }
        public string PASSWORD { get; set; }

        public string Login(string connection)
        {
            using (SqlConnection conn = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("SP_API_LOGIN", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@USERNAME", SqlDbType.VarChar).Value = USERNAME;
                cmd.Parameters.Add("@PASSWORD", SqlDbType.VarChar).Value = PASSWORD;
                conn.Open();
                return cmd.ExecuteScalar().ToString();

            }
        }
    }
}
