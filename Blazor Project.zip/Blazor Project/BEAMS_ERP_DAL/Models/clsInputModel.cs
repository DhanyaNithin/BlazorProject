﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace BEAMS_ERP_DAL.Models
{
    public class clsInputModel
    {
        public IEnumerable<ControlSettings> CONTROLSETTING { get; set; }
        public IEnumerable<ControlSettings> CONTROLSETTINGDET { get; set; }
        public string[] STRDATA { get; set; }
        public DateTime?[] STRDATEDATA { get; set; }
        public bool[] STRBOOLDATA { get; set; }
        public int?[] STRINTDATA { get; set; }
        public decimal?[] STRDECIMALDATA { get; set; }
        public List<clsGridDataModel> GridData { get; set; }
        public string? CODE { get; set; }
        public string? MODE { get; set; }
        public string? COMPANY { get; set; }
        public string? YEARCODE { get; set; }
        public string? USERNAME { get; set; }

        public string SaveData(string connectionstring)
        {
            String SPNAME = String.Empty;
            if (CODE == "CM")
            {
                SPNAME = "PR_SAVE_CITYMASTER";
            }
            else if (CODE == "INV")
            {
                SPNAME = "PR_SAVE_ERPINV";
            }
            if (!string.IsNullOrEmpty(SPNAME))
            {
                using (SqlConnection con = new SqlConnection(connectionstring))
                {
                    con.Open();
                    try
                    {
                        using (SqlCommand command = new SqlCommand(SPNAME, con))
                        {
                            command.CommandType = CommandType.StoredProcedure;
                            var groupedSettings = CONTROLSETTING.Where(setting => !string.IsNullOrEmpty(setting.TABLE_TYPE)).GroupBy(setting => setting.TABLE_TYPE);
                            foreach (var group in groupedSettings)
                            {
                                if (group.Where(P => !string.IsNullOrEmpty(P.FIELD_NAME)).Count() > 0)
                                {
                                    TableType TT1 = new TableType();
                                    TT1.TYPE_NAME = group.Key;
                                    DataTable HEADER_TABLE = TT1.mfnCreateTypeTable(connectionstring);
                                    DataRow row = HEADER_TABLE.NewRow();

                                    foreach (var setting in group.Where(P => !string.IsNullOrEmpty(P.FIELD_NAME)))
                                    {
                                        var fieldlist = setting.FIELD_NAME.Split('|');
                                        foreach (var field in fieldlist)
                                        {
                                            if (setting.CTL_TYPE == "DATE")
                                            {
                                                row[field] = STRDATEDATA[setting.SRNO - 1];
                                            }
                                            else if (setting.CTL_TYPE == "CHECKBOX")
                                            {
                                                if (STRBOOLDATA[setting.SRNO - 1])
                                                {
                                                    row[field] = "Y";
                                                }
                                                else
                                                {
                                                    row[field] = "N";
                                                }
                                            }
                                            else if (setting.CTL_TYPE == "RADIOGROUP")
                                            {
                                                foreach (var radiobutton in CONTROLSETTING.Where(cs => cs.PARENT_CONTROL == setting.CTL_NAME))
                                                {
                                                    if (STRBOOLDATA[radiobutton.SRNO - 1])
                                                    {
                                                        row[field] = radiobutton.DEFAULT_VALUE;
                                                    }
                                                }
                                            }
                                            else if (setting.CTL_TYPE == "NUMBER")
                                            {
                                                row[field] = STRINTDATA[setting.SRNO - 1];
                                            }
                                            else if (setting.CTL_TYPE == "DECIMAL")
                                            {
                                                row[field] = STRDECIMALDATA[setting.SRNO - 1];
                                            }
                                            else
                                            {
                                                row[field] = STRDATA[setting.SRNO - 1];
                                            }
                                        }
                                    }
                                    if (HEADER_TABLE.Columns.Contains("COMPANY") && string.IsNullOrEmpty(row["COMPANY"].ToString()))
                                    {
                                        row["COMPANY"] = COMPANY;
                                    }
                                    if (HEADER_TABLE.Columns.Contains("YEARCODE") && string.IsNullOrEmpty(row["YEARCODE"].ToString()))
                                    {
                                        row["YEARCODE"] = YEARCODE;
                                    }
                                    if (HEADER_TABLE.Columns.Contains("DOCTYPE") && string.IsNullOrEmpty(row["DOCTYPE"].ToString()))
                                    {
                                        row["DOCTYPE"] = CODE;
                                    }
                                    if (HEADER_TABLE.Columns.Contains("CREATE_USER") && string.IsNullOrEmpty(row["CREATE_USER"].ToString()))
                                    {
                                        row["CREATE_USER"] = USERNAME;
                                    }
                                    if (HEADER_TABLE.Columns.Contains("EDIT_USER") && string.IsNullOrEmpty(row["EDIT_USER"].ToString()))
                                    {
                                        row["EDIT_USER"] = USERNAME;
                                    }
                                    if(GridData.Count() > 0)
                                    {
                                        if (HEADER_TABLE.Columns.Contains("GRAMT") && string.IsNullOrEmpty(row["GRAMT"].ToString()))
                                        {
                                            row["GRAMT"] = GridData.Sum(i => i.GRAMT);
                                        }
                                        if (HEADER_TABLE.Columns.Contains("GRAMTFC") && string.IsNullOrEmpty(row["GRAMTFC"].ToString()))
                                        {
                                            row["GRAMTFC"] = GridData.Sum(i => i.GRAMTFC);
                                        }
                                        if (HEADER_TABLE.Columns.Contains("DISC_AMT") && string.IsNullOrEmpty(row["DISC_AMT"].ToString()))
                                        {
                                            row["DISC_AMT"] = GridData.Sum(i => i.DISC_AMT);
                                        }
                                        if (HEADER_TABLE.Columns.Contains("DISC_AMTFC") && string.IsNullOrEmpty(row["DISC_AMTFC"].ToString()))
                                        {
                                            row["DISC_AMTFC"] = GridData.Sum(i => i.DISC_AMTFC);
                                        }
                                        if (HEADER_TABLE.Columns.Contains("NETAMT") && string.IsNullOrEmpty(row["NETAMT"].ToString()))
                                        {
                                            row["NETAMT"] = GridData.Sum(i => i.AMT);
                                        }
                                        if (HEADER_TABLE.Columns.Contains("NETAMTFC") && string.IsNullOrEmpty(row["NETAMTFC"].ToString()))
                                        {
                                            row["NETAMTFC"] = GridData.Sum(i => i.AMTFC);
                                        }
                                    }
                                    

                                    HEADER_TABLE.Rows.Add(row);
                                    command.Parameters.Add(group.Key, SqlDbType.Structured).Value = HEADER_TABLE;
                                }
                            }
                            var gridSettings = CONTROLSETTINGDET.Where(setting => !string.IsNullOrEmpty(setting.TABLE_TYPE)).GroupBy(setting => setting.TABLE_TYPE);
                            foreach (var group in gridSettings)
                            {
                                if (group.Where(P => !string.IsNullOrEmpty(P.FIELD_NAME)).Count() > 0)
                                {
                                    TableType TT1 = new TableType();
                                    TT1.TYPE_NAME = group.Key;
                                    DataTable DET_TABLE = TT1.mfnCreateTypeTable(connectionstring);
                                    var properties = typeof(clsGridDataModel).GetProperties();
                                    int SRNO = 1;
                                    foreach (var item in GridData)
                                    {
                                        DataRow row = DET_TABLE.NewRow();
                                        foreach (var setting in group.Where(P => !string.IsNullOrEmpty(P.FIELD_NAME)))
                                        {
                                            var fieldlist = setting.FIELD_NAME.Split('|');
                                            foreach (var field in fieldlist)
                                            {
                                                var matchedProperty = properties.FirstOrDefault(p => p.Name == field);
                                                if (matchedProperty != null)
                                                {
                                                    if (setting.CTL_TYPE == "IDENTITY")
                                                    {
                                                        row[field] = SRNO;
                                                        SRNO++;
                                                    }
                                                    else
                                                    {
                                                        row[field] = matchedProperty.GetValue(item);
                                                    }
                                                }
                                            }
                                        }
                                        if (DET_TABLE.Columns.Contains("COMPANY") && string.IsNullOrEmpty(row["COMPANY"].ToString()))
                                        {
                                            row["COMPANY"] = COMPANY;
                                        }
                                        if (DET_TABLE.Columns.Contains("YEARCODE") && string.IsNullOrEmpty(row["YEARCODE"].ToString()))
                                        {
                                            row["YEARCODE"] = YEARCODE;
                                        }
                                        if (DET_TABLE.Columns.Contains("DOCTYPE") && string.IsNullOrEmpty(row["DOCTYPE"].ToString()))
                                        {
                                            row["DOCTYPE"] = CODE;
                                        }
                                        if (DET_TABLE.Columns.Contains("CREATE_USER") && string.IsNullOrEmpty(row["CREATE_USER"].ToString()))
                                        {
                                            row["CREATE_USER"] = USERNAME;
                                        }
                                        if (DET_TABLE.Columns.Contains("EDIT_USER") && string.IsNullOrEmpty(row["EDIT_USER"].ToString()))
                                        {
                                            row["EDIT_USER"] = USERNAME;
                                        }
                                        if (DET_TABLE.Columns.Contains("DOCNO") && string.IsNullOrEmpty(row["DOCNO"].ToString()))
                                        {
                                            row["DOCNO"] = "0";
                                        }
                                        DET_TABLE.Rows.Add(row);
                                    }
                                    command.Parameters.Add(group.Key, SqlDbType.Structured).Value = DET_TABLE;
                                }
                            }
                            command.Parameters.Add("MODE", SqlDbType.VarChar).Value = MODE;
                            command.ExecuteNonQuery();
                        }

                    }
                    catch (Exception ex)
                    {
                        return "Failed";
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return "Success";
        }
    }

    public class clsControlSettings
    {
        public string? COMPANY { get; set; }
        public string? CODE { get; set; }
        public string? LANGUAGE { get; set; }
    }
}
