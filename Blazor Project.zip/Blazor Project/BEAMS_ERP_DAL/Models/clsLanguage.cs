﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class clsLanguage
    {
        public string CODE { get; set; } = "";
        public string DESCP { get; set; } = "";
        public string RTL_YN { get; set; } = "";
        public string DESCP_LOCAL { get; set; } = "";

        public IEnumerable<clsLanguage> GetAllLanguages(string connection)
        {
            List<clsLanguage> _language = new List<clsLanguage>();
            using (SqlConnection conn = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("sp_LANGUAGEMASTER", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader ldrOLE = cmd.ExecuteReader();
                while (ldrOLE.Read())
                {
                    clsLanguage lang = new clsLanguage();
                    lang.CODE = Convert.ToString(ldrOLE["CODE"]);
                    lang.DESCP = Convert.ToString(ldrOLE["DESCP"]);
                    lang.RTL_YN = Convert.ToString(ldrOLE["RTL_YN"]);
                    lang.DESCP_LOCAL = Convert.ToString(ldrOLE["DESCP_LOCAL"]);
                    _language.Add(lang);
                }
                conn.Close();
            }
            return _language;
        }
    }
}
