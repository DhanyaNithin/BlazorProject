﻿using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;

namespace BEAMS_ERP_DAL.Models
{
    public class Beams0000 : IDisposable
    {
        private IntPtr handle;
        private Component component = new Component();
        private bool _Disposed = false;

        #region Constructor
        public Beams0000()
        {

        }

        public Beams0000(IntPtr handle)
        {
            this.handle = handle;
        }

        #endregion

        #region Dispose
        /// <summary>
        /// Ref: http://msdn.microsoft.com/en-us/library/system.idisposable%28v=vs.71%29.aspx
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!this._Disposed)
            {
                if (disposing)
                {
                    component.Dispose();
                }

                CloseHandle(handle);
                handle = IntPtr.Zero;
            }

            _Disposed = true;
        }

        [System.Runtime.InteropServices.DllImport("Kernel32")]
        private extern static Boolean CloseHandle(IntPtr handle);

        ~Beams0000()
        {
            Dispose(false);
        }

        #endregion


        public string getDB(string Company, string Yearcode, string connectionstring)
        {

            string result = "";
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_GETCONNECTION_FROM_COMPANY_JOB", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("COMPANY", Company);
                cmd.Parameters.AddWithValue("YEARCODE", Yearcode);
                
                con.Open();
                

                try
                {
                    result = cmd.ExecuteScalar().ToString();
                }
                catch (Exception ex)
                {
                    string lStrSql = "CREATE PROCEDURE [dbo].[SP_GETCONNECTION_FROM_COMPANY_JOB]  " +
       "@COMPANY NVARCHAR(100),  " +
       "@YEARCODE NVARCHAR(10)  " +
       "AS BEGIN  " +
       "SELECT BEAMS_DATABASE_NAME FROM BEAMS_YEAR_DATA_JOB WHERE COMPANY_CODE=@COMPANY AND YEARCODE=@YEARCODE  " +
       "END  ";
                    con.Close();
                    con.Open();
                    SqlCommand cmd2 = new SqlCommand(lStrSql,con);
                    cmd2.ExecuteNonQuery();
                    throw ex;
                }
                con.Close();
                return result;
            }
  
        }


        public DataTable GetConnection(string Company, string Yearcode, string connectionstring)
        {
            DataTable result = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_DB_FROM_COMPANY_JOB", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("COMPANY", Company);
                cmd.Parameters.AddWithValue("YEARCODE", Yearcode);

                con.Open();


                try
                {
                    result.Load(cmd.ExecuteReader());
                }
                catch (Exception ex)
                {
                    string lStrSql = "CREATE PROCEDURE [dbo].[SP_DB_FROM_COMPANY_JOB]  " +
   "@COMPANY NVARCHAR(100),  " +
   "@YEARCODE NVARCHAR(10)  " +
   "AS BEGIN  " +
   "SELECT * FROM BEAMS_YEAR_DATA_JOB WHERE COMPANY_CODE=@COMPANY AND YEARCODE=@YEARCODE  " +
   "END  ";
                    con.Close();
                    con.Open();
                    SqlCommand cmd2 = new SqlCommand(lStrSql, con);
                    cmd2.ExecuteNonQuery();
                    throw ex;
                }
                con.Close();
                return result;
            }
        }

    }
}
