﻿using Microsoft.Data.SqlClient;
using System.ComponentModel;
using System.Data;

namespace BEAMS_ERP_DAL.Models
{
    public class TableType
    {
        private IntPtr handle;
        private Component component = new Component();
        private bool _Disposed = false;

        internal static DataSet _TypeSet = new DataSet();


        #region Get or Set TypeSet
        public DataSet TypeSet
        {
            set
            {
                _TypeSet = value;
            }
            get
            {
                return _TypeSet;
            }
        }

        #endregion



        #region Constructor
        public TableType()
        {

        }

        public TableType(IntPtr handle)
        {
            this.handle = handle;
        }

        #endregion

        #region Dispose
        /// <summary>
        /// Ref: http://msdn.microsoft.com/en-us/library/system.idisposable%28v=vs.71%29.aspx
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!this._Disposed)
            {
                if (disposing)
                {
                    component.Dispose();
                }

                CloseHandle(handle);
                handle = IntPtr.Zero;
            }

            _Disposed = true;
        }

        [System.Runtime.InteropServices.DllImport("Kernel32")]
        private extern static Boolean CloseHandle(IntPtr handle);

        ~TableType()
        {
            Dispose(false);
        }

        #endregion
        //ConfigReader configReader = new ConfigReader();
        public string TYPE_NAME { get; set; }

        public DataTable mfnCreateTypeTable(string connectionstring)
        {
            DataTable TblResult = new DataTable();
            try
            {
                if (TypeSet.Tables[TYPE_NAME] != null)
                {
                    TypeSet.Tables[TYPE_NAME].Clear();
                    TblResult = TypeSet.Tables[TYPE_NAME].Clone();
                    return TblResult;
                }
            }
            catch
            {

            }


            DataTable TblTemp = new DataTable();
            var TableColumns = mfnTabletypeDef(connectionstring);

            foreach (DataRow dr in TableColumns.Rows)
            {
                TblResult.Columns.Add(dr["name"].ToString());
                TblTemp.Columns.Add(dr["name"].ToString());
            }
            try
            {
                TblTemp.TableName = TYPE_NAME;
                TypeSet.Tables.Add(TblTemp);
            }
            catch
            {

            }
            return TblResult;
        }
        public DataTable mfnTabletypeDef(string connectionstring)
        {
            DataTable TblResult = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                con.Open();
                try
                {
                    using (SqlCommand command = new SqlCommand("SP_TABLE_TYPE", con))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("TYPE_NAME", TYPE_NAME);
                        TblResult.Load(command.ExecuteReader());
                    }

                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    con.Close();
                }

            }
            return TblResult;
        }
    }
}
