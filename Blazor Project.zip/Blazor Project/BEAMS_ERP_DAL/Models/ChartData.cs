﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class ChartData
    {
        public string Label { get; set; }
        public double Value { get; set; }
        public double Category { get; set; }
    }

    public class ChartDataInput
    {
        public string COMPANY { get; set; }

        public List<ChartData> GetTotalSales(string connectionstring)
        {
            List<ChartData> acsList = new List<ChartData>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("PR_HOME_RPT", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("COMPANY", COMPANY);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ChartData iData = new ChartData();
                    iData.Label = Convert.ToString(dr["MONTH"]);
                    iData.Value = Convert.ToDouble(dr["COLLECTION"]);
                    acsList.Add(iData);
                }
                con.Close();
            }
            return acsList;
        }

        public List<ChartData> GetTotalNoSales(string connectionstring)
        {
            List<ChartData> acsList = new List<ChartData>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("PR_HOME_RPT", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("COMPANY", COMPANY);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ChartData iData = new ChartData();
                    iData.Label = Convert.ToString(dr["MONTH"]);
                    iData.Value = Convert.ToDouble(dr["COUNT"]);
                    acsList.Add(iData);
                }
                con.Close();
            }
            return acsList;
        }
    }
}
