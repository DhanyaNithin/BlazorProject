﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace BEAMS_ERP_DAL.Models
{
    public class Lookup
    {
        public string lstrTable { get; set; } = string.Empty;
        public string lstrSearchColumn { get; set; } = string.Empty;
        public string lstrFilter { get; set; } = string.Empty;
        public IEnumerable<clsLookupModel> LookupSearch(string connectionstring)
        {
            List<clsLookupModel> acsList = new List<clsLookupModel>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_LOOKUP_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("TABLE_NAME", lstrTable);
                cmd.Parameters.AddWithValue("COLUMNS", lstrSearchColumn);
                cmd.Parameters.AddWithValue("FILTER", lstrFilter);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    clsLookupModel iData = new clsLookupModel();
                    iData.DESCP = Convert.ToString(dr["DESCP"]);
                    iData.CODE = Convert.ToString(dr["CODE"]);
                    acsList.Add(iData);
                }
                con.Close();
            }
            return acsList;
        }

        public DataTable LookupValidate(string connectionstring)
        {
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_LKP_VALIDATE", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("TABLE", lstrTable);
                cmd.Parameters.AddWithValue("COLUMNS", lstrSearchColumn);
                cmd.Parameters.AddWithValue("FILTER", lstrFilter);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                using (var table = new DataTable())
                {
                    table.Load(dr);
                    dr.Close();
                    return table;
                }

            }

        }
    }
}
