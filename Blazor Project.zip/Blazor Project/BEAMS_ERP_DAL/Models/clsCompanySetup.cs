﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace BEAMS_ERP_DAL.Models
{
    public class clsCompanySetup
    {
        public string COMPANY_CODE { get; set; } = "";
        public string ERP_COMPANY_NAME { get; set; } = "";
        public string YEARCODE { get; set; } = "";

        public IEnumerable<clsCompanySetup> GetAllCompany(string connection) 
        { 
            List<clsCompanySetup> _clsCompanySetup = new List<clsCompanySetup>();
            using (SqlConnection conn = new SqlConnection(connection)) 
            {
                SqlCommand cmd = new SqlCommand("SP_BEAMS_GET_COMPANY", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader ldrOLE = cmd.ExecuteReader();
                while (ldrOLE.Read()) 
                { 
                    clsCompanySetup companySetup = new clsCompanySetup();
                    companySetup.COMPANY_CODE = Convert.ToString(ldrOLE["COMPANY_CODE"]);
                    companySetup.ERP_COMPANY_NAME = Convert.ToString(ldrOLE["ERP_COMPANY_NAME"]);
                    _clsCompanySetup.Add(companySetup);
                }
                conn.Close();
            }
            return _clsCompanySetup;
        }

        public IEnumerable<clsCompanySetup> GetCompanyYearData(string connection)
        {
            List<clsCompanySetup> _clsCompanyYearCode = new List<clsCompanySetup>();
            using (SqlConnection conn = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("SP_BEAMS_GET_YEAR", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("COMPANY",COMPANY_CODE);
                conn.Open();
                SqlDataReader ldrOLE = cmd.ExecuteReader();
                while (ldrOLE.Read())
                {
                    clsCompanySetup clsCompanyYear = new clsCompanySetup();
                    clsCompanyYear.COMPANY_CODE = Convert.ToString(ldrOLE["COMPANY_CODE"]);
                    clsCompanyYear.YEARCODE = Convert.ToString(ldrOLE["YEARCODE"]);
                    _clsCompanyYearCode.Add(clsCompanyYear);

                }
                conn.Close();
            }
            return _clsCompanyYearCode;
        }
    }
}
