﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class ControlSettingsURL
    {
        public string? DOCTYPE { get; set; }
        public string? MODE { get; set; }
        public int SRNO { get; set; }
        public string? URL { get; set; }
        public string? PARAM { get; set; }
        public string? KEYS { get; set; }

        public IEnumerable<ControlSettingsURL> GetControlSettingURL(string connectionstring)
        {
            List<ControlSettingsURL> acsList = new List<ControlSettingsURL>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("PR_GET_CONTROL_SETTING_URLS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("DOCTYPE", DOCTYPE);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ControlSettingsURL iData = new ControlSettingsURL();
                    iData.DOCTYPE = Convert.ToString(dr["DOCTYPE"]);
                    iData.MODE = Convert.ToString(dr["MODE"]);
                    iData.SRNO = Convert.ToInt32(dr["SRNO"]);
                    iData.URL = Convert.ToString(dr["URL"]);
                    iData.PARAM = Convert.ToString(dr["PARAM"]);
                    iData.KEYS = Convert.ToString(dr["KEYS"]);
                    acsList.Add(iData);
                }
                con.Close();
            }
            return acsList;
        }
    }
}
