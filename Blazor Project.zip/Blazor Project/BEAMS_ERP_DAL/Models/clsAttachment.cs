﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEAMS_ERP_DAL.Models
{
    public class clsAttachment
    {
        public string COMPANY { get; set; }
        public string YEARCODE { get; set; }
        public string DOCNO { get; set; }
        public string DOCTYPE { get; set; }
        public int SRNO { get; set; }
        public string FILE_DATA { get; set; }
        public string IMAGE { get; set; }
        public string FILE_NAME { get; set; }
        public string FILE_TYPE { get; set; }
        public string FILE_DESCP { get; set; }
    }
}
